# Changelog

## 1.1.0

- Adds update-focused CRM trend and routing telemetry blocks
- Refines settings schema defaults for operational tuning
- Intended for manual install-update flow validation

## 1.0.0

- Initial CRM Insights Console declarative package
