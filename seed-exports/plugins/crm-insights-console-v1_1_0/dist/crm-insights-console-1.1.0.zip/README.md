# CRM Insights Console

CRM Insights Console v1.1.0 is an update package for the existing phase-one declarative CRM plugin.

## Update focus

- Adds clearer trend and routing context in the host-rendered dashboard preview
- Keeps lifecycle fully declarative and host-owned
- Preserves compatibility with existing CRM plugin installation flow

## Phase-one boundary

This package includes only JSON, Markdown, and signature metadata. No executable client or server bundles are included.
