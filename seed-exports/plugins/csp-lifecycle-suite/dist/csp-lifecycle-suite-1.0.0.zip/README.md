# CSP Lifecycle Suite Plugin v1.0.0

**Complete Community Support Program (CSP) lifecycle management with broadcast visibility auditing, real-time communication feeds, and lifecycle email notifications.**

---

## Overview

The CSP Lifecycle Suite plugin delivers three complete feature implementations for the BPI Community Support Program:

1. **Broadcast Visibility Guard** (PLG-502): Prevents stale broadcast data from lingering in user feeds with automatic cache invalidation and 15-second refresh intervals.

2. **Visibility Diagnostics** (PLG-503): Admin-facing accountability showing exactly why broadcasts are hidden from user feeds with reason classifications and audit trails.

3. **Lifecycle Communication Suite** (PLG-601): Real-time user notifications with styled HTML lifecycle emails for CSP milestones (request submitted, broadcast live, broadcast complete, contribution processed).

---

## Features

### 1. Broadcast Visibility Guard

**What It Does:**
- Implements shared broadcast visibility logic preventing stale data in user feeds
- Dashboard auto-refreshes CSP feed every 15 seconds with client-side filtering
- Admin mutations automatically invalidate user caches

**User Impact:**
- Broadcast status changes appear within 15 seconds without page refresh
- Guaranteed consistency: users never see conflicts between request status and broadcast visibility

**Admin Controls:**
- All status mutations (approve, extend, release, complete) trigger immediate cache invalidation
- No manual cache clear buttons needed

### 2. Visibility Diagnostics Panel

**What It Does:**
- Exposes hidden broadcast audit API endpoint
- Admin CSP panel displays breakdown of hidden broadcasts by reason
- Shows sample hidden requests with owner, expiry date, and hidden reason

**Admin Impact:**
- Immediate visibility into why broadcasts are excluded from feeds
- Reason breakdown: inactive, not_broadcasting, missing_expiry (deadline passed without field set), expired
- Sample hidden requests table (configurable limit: 5-500)
- Auto-refresh on mutations (no manual "refresh diagnostics" button needed)

**Compliance:**
- Full audit trail of visibility decisions
- Diagnostic counts verified against actual broadcast states

### 3. Lifecycle Communication Suite

**What It Does:**
- Sends styled HTML emails for CSP milestones: request received, broadcast live, broadcast extended, broadcast complete, contribution processed, request rejected
- Real-time communication feed in user dashboard showing request timeline + notification history
- Dashboard replaces hardcoded static checklist with dynamic data from backend

**User Impact:**
- Receive professional HTML emails with BPI branding for each CSP lifecycle event
- Subject line examples: "CSP: Request received", "CSP: Broadcast complete and funded"
- Dashboard shows real communication history instead of generic checklist
- Email fallback: if SMTP misconfigured, in-app notifications still work

**Features:**
- Graceful error handling: email delivery failures don't block notifications
- Personalized emails with user name and request details
- CTA links in emails directing to dashboard
- Communication feed auto-syncs when user takes actions (submit request, contribute, receive funds)

---

## Installation & Activation

### 1. Upload Plugin Bundle
1. Log in to Admin Panel > Plugins > Plugin Inventory
2. Click "Upload New Plugin"
3. Select `csp-lifecycle-suite-1.0.0.zip`
4. Review manifest and capabilities
5. Approve requested permissions
6. Click "Install"

### 2. Configure Settings
1. Go to Admin Panel > Plugins > CSP Lifecycle Suite
2. Under "Settings" tab, configure:
   - **Enable Lifecycle Emails:** Toggle to send HTML emails (default: ON)
   - **Cache Refresh Interval:** Set to 15-60 seconds (default: 15)
   - **Enable Visibility Diagnostics:** Toggle admin audit panel (default: ON)
   - **SMTP From Address:** Set to valid sender email (must match SMTP config)
   - **Enable Audit Logging:** Toggle compliance logging (default: ON)
3. Save settings

### 3. Verify Installation
1. Go to Admin Panel > CSP Lifecycle Management
2. Verify "Diagnostics" panel appears (if diagnostics enabled)
3. Dashboard should show real communication history, not static checklist
4. Test user flow: submit request, verify email received

### 4. Monitor Health
1. Check "Health" tab in plugin detail
2. Status should show "READY" (green)
3. Monitor error messages for SMTP or database issues

---

## Configuration

### Required Settings

**SMTP Configuration** (for email delivery)
- Host: Your email provider's SMTP server (e.g., smtp.gmail.com)
- Port: 587 (TLS) or 465 (SSL)
- Username: Your email account
- Password: App-specific password (not personal password)
- From Address: noreply@bpi.local (or configured domain)

Configure in Admin > Settings > Email Configuration before enabling lifecycle emails.

### Optional Settings

| Setting | Default | Range | Purpose |
|---------|---------|-------|---------|
| `enableLifecycleEmails` | true | boolean | Send HTML emails for CSP events |
| `cacheRefreshInterval` | 15 | 5-300 sec | Dashboard feed refresh frequency |
| `enableVisibilityDiagnostics` | true | boolean | Show admin audit panel |
| `diagnosticsSampleLimit` | 50 | 5-500 | Max hidden broadcasts shown |
| `enableAuditLogging` | true | boolean | Log lifecycle events |
| `notificationRetentionDays` | 90 | 7-730 days | Communication history retention |

---

## API Endpoints (Internal)

The plugin exposes these tRPC procedures for dashboard and admin panel:

### `csp.getCommunicationFeed` (protectedProcedure)
**Used By:** User dashboard CSP section
**Returns:** 
- `requestTimeline[]`: Last 6 CSP requests with status, timeline stages, dates
- `notifications[]`: Last 8 CSP-tagged notifications with titles and messages

**Refresh Behavior:** 
- Stale time: 60 seconds
- Refetch on: Window focus, user mutations (submit request, contribute, receive funds)
- Manual refresh: Dashboard has refresh button

### `csp.getBroadcastVisibilityDiagnostics` (protectedProcedure - Admin Only)
**Used By:** Admin CSP panel diagnostics section
**Returns:**
- `scannedCount`: Total broadcasts evaluated
- `visibleCount`: Broadcasts currently visible to users
- `hiddenCount`: Broadcasts hidden from user feeds
- `hiddenReasonBreakdown`: Count of each hidden reason (inactive, not_broadcasting, missing_expiry, expired)
- `hiddenBroadcasts[]`: Sample of hidden requests with reason, expiry, owner

**Refresh Behavior:**
- Auto-refresh on admin mutations
- Manual refresh button available
- Updates within 1-2 seconds of mutation

---

## User Experience

### User Dashboard (CSP Section)

**Before Plugin:**
- Hardcoded checklist items ("Qualification notice", "Approval + broadcast", etc.)
- Static placeholder notifications
- No real communication history

**After Plugin:**
- Real "Request Timeline" showing actual CSP requests with status and stage labels
- Real "Communication History" showing lifecycle notifications from backend
- Auto-refreshing every 15 seconds
- Email notifications received for each lifecycle event

### Admin CSP Panel

**New Section: Visibility Diagnostics**
- **Widget 1:** Broadcast counts (Scanned | Visible | Hidden)
- **Widget 2:** Hidden reason breakdown (inactive, not_broadcasting, missing_expiry, expired)
- **Widget 3:** Hidden Broadcasts table showing 5-500 sample requests with:
  - Request ID
  - Status badge
  - Hidden reason badge
  - Expiry date
  - Owner email
- **Control:** Refresh button (or auto-refresh on mutations)

---

## Compliance & Audit

The plugin includes:

1. **Comprehensive Audit Logging**
   - All CSP lifecycle events logged to plugin audit trail
   - Visibility decisions recorded with reason classifications
   - Admin mutations tracked with user attribution

2. **Data Retention**
   - Notifications retained for 90 days (configurable)
   - Audit logs retained per retention policy
   - Hidden broadcast history available in diagnostics

3. **Permission Boundaries**
   - Only authenticated admins see visibility diagnostics
   - Users only see communications relevant to their CSP history
   - All API endpoints require `protectedProcedure` auth

---

## Testing Checklist

### Automated Quality Gates
```bash
npm test                # Run all tests
npm run lint           # ESLint validation
npm run type-check     # TypeScript validation
npm run build          # Production build
```

Expected Results:
- ✅ 9/9 unit tests passing (includes 2 new PLG-601 tests)
- ✅ 0 ESLint warnings or errors
- ✅ 0 TypeScript compilation errors
- ✅ Build succeeds with 108+ static pages
- ✅ No diagnostics or warnings

### Manual User Testing

1. **User submits CSP request:**
   - Verify in-app notification: "CSP: Request received"
   - Check email inbox: Styled HTML email received
   - Verify dashboard shows request in "Request Timeline"

2. **Admin approves request:**
   - Verify user's dashboard updates within 15 seconds (no page refresh)
   - Verify broadcast status changes to "broadcast_live"
   - Check user email: "CSP: Broadcast live" notification received

3. **User contributes and threshold is met:**
   - Verify "CSP: Broadcast complete and funded" notification sent
   - Check request timeline shows "broadcast_complete" status
   - User receives completion email

4. **Admin releases funds:**
   - Verify user gets "Your contribution was processed" notification
   - Check email received
   - Verify timeline shows "released" status

### Manual Admin Testing

1. **Admin panel loads:**
   - Navigate to Admin > CSP Lifecycle Management
   - Verify "Diagnostics" panel is visible
   - Counts should appear: Scanned, Visible, Hidden

2. **Visibility diagnostics work:**
   - Check hidden reason breakdown displays
   - Verify hidden broadcasts table shows sample requests
   - Click reason badge: tooltip appears

3. **Auto-refresh works:**
   - Approve a request
   - Observe diagnostics panel WITHOUT clicking refresh
   - Counts update within 1-2 seconds

---

## Troubleshooting

### Issue: Emails not sending
**Cause:** SMTP misconfigured  
**Resolution:**
1. Go to Admin > Settings > Email Configuration
2. Verify SMTP credentials
3. Click "Test Email" to verify connectivity
4. Check notification service logs
5. In-app notifications still work (email is optional)

### Issue: Dashboard shows old data
**Cause:** Cache not refreshing  
**Resolution:**
1. Check browser DevTools Network tab
2. Verify `getCommunicationFeed` requests appear every 15 seconds
3. Adjust `cacheRefreshInterval` in plugin settings (lower = more frequent)
4. Manual refresh button in CSP Dashboard

### Issue: Diagnostics panel shows incorrect counts
**Cause:** Stale cached data  
**Resolution:**
1. Click "Refresh" button in diagnostics panel
2. Verify mutation just completed (approve/extend/release)
3. Check plugin health status in admin panel

### Issue: User sees stale request status for >15 seconds
**Cause:** Network latency or client cache issue  
**Resolution:**
1. Manually trigger window focus (click browser tab)
2. Adjust `cacheRefreshInterval` to lower value
3. Check browser network connectivity
4. Verify API response time isn't excessive

---

## Performance Impact

| Metric | Before | After | Impact |
|--------|--------|-------|--------|
| Admin Page Bundle | 13.8 kB | 14.7 kB | +0.9 kB (6.5%) |
| Dashboard Page Bundle | 12.5 kB | 13.1 kB | +0.6 kB (4.8%) |
| Build Time | ~75s | ~75s | 0% |
| API Latency | — | <100ms | Negligible |
| Cache Refresh Overhead | — | ~50ms per 15s | <1% CPU |

**Conclusion:** Negligible performance impact, suitable for production.

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-05-19 | Initial release: PLG-502, PLG-503, PLG-601 |

---

## Support

**For Installation Issues:**
- Email: plugins-support@bpi.local
- Online: https://bpi.local/support/plugins/csp

**For Bug Reports:**
- Include: plugin version, reproduction steps, error messages
- Check logs: Admin > Plugins > CSP Lifecycle Suite > Health tab

**For Feature Requests:**
- Submit: Admin > Plugins > CSP Lifecycle Suite > Feedback
- Provide: Use case, impact, desired outcome

---

## License

This plugin is proprietary to BPI Platform. All rights reserved.

---

**Plugin Status:** ✅ Production Ready | **Quality Gates:** All Passing | **Tested:** ✅ Comprehensive
