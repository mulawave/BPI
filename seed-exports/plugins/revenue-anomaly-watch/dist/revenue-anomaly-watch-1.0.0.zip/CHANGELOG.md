# Changelog

## 1.0.0

- Initial Revenue Anomaly Watch package for manual plugin flow testing
- Provides declarative page and settings schema references
- Includes phase-one signature metadata
