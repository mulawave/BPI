# Revenue Anomaly Watch

Revenue Anomaly Watch is a phase-one declarative plugin package for manual plugin onboarding flow validation.

## Included surfaces

- Analytics admin navigation registration
- Host-rendered anomaly signal dashboard preview
- Declarative plugin settings for threshold tuning
- Readiness and health metadata for lifecycle checks

## Phase-one boundary

This package contains JSON, Markdown, and signature metadata only. It does not include executable runtime bundles.
