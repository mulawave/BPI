# CRM Insights Console

CRM Insights Console is a phase-one declarative sample plugin for the BPI admin plugin system.

## Included surfaces

- Analytics-focused admin navigation registration
- Host-rendered plugin detail preview blocks
- Plugin-scoped settings and secret references
- Webhook and background job metadata
- Health and readiness metadata

## Phase-one boundary

This package contains only JSON, Markdown, and signature metadata. It does not contain executable client or server bundles.