# Changelog

## 1.0.0

- Initial sample bundle for phase-one plugin admin UX testing
- Adds declarative page schema, settings schema, and signature metadata
- Designed for upload validation and Prisma seeding drills